alert("练琴了吗您？");
var arr=["老麦克唐纳","芭蕾舞者","会跳舞的熊","青花瓷","班吉尼故乡","安静","山外"]
var index=parseInt(Math.random()*arr.length)
document.getElementById("su").value=arr[index];
var objectdiv=document.getElementById('s_kw_wrap');
objectdiv.click();