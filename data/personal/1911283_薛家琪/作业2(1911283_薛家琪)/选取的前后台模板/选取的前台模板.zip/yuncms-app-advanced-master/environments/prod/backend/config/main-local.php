<?php
return [
    'components' => [
        'request' => [
            // !!! 在下面设置一个安全密钥 (如果为空) - 这是Cookie 所必须的。
            'cookieValidationKey' => '',
        ],
    ],
];
