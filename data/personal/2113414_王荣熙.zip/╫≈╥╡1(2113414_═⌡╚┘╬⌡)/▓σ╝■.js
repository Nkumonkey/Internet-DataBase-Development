// ==UserScript==
// @name         反防切屏
// @version      0.1
// @description  针对网站anti切屏的anti
// @match        http://127.0.0.1:5500/test.html
// @run-at       document-start
// ==/UserScript==

(function() {
  'use strict';

  var stopOtherHandler = function(e) {
    e.stopImmediatePropagation();
    e.stopPropagation();
    e.preventDefault();
  }

  var cancelHandler = function(e) {
    document.addEventListener('visibilitychange', stopOtherHandler);
    window.addEventListener('focus', stopOtherHandler);
    window.addEventListener('blur', stopOtherHandler);
    document.onvisibilitychange = window.onblur = window.onfocus = null;
  }

  cancelHandler();

  window.addEventListener('load', function(e) {
    cancelHandler();
    setInterval(function(){
      document.onvisibilitychange = window.onblur = window.onfocus = null;
    }, 1000);
  });
})();