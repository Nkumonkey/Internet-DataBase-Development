<?php

use yii\helpers\Url;
use yii\helpers\Html;

$this->title = Yii::t('app', 'Wechat Page');

/* @var $this \yii\web\View */


?>
