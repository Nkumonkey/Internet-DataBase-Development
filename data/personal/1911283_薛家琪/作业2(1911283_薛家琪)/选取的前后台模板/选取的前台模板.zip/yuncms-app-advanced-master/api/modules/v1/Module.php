<?php

namespace api\modules\v1;


/**
 * Class Module
 * @package api\modules\v1
 */
class Module extends \yii\base\Module
{

}