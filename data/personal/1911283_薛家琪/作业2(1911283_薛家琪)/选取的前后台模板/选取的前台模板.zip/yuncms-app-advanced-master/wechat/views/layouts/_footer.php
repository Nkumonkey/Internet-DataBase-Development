<?php
/* @var $this \yii\web\View */
?>
<div class="weui-footer">
    <p class="weui-footer__text">Copyright &copy; <?=Yii::$app->name?> <?= date('Y') ?></p>
</div>