// ==UserScript==
// @name         Hide All Img
// @namespace    http://tampermonkey.net/
// @version      2023-12-20
// @description  try to take over the world!
// @author       You
// @match        *://*/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    // Your code here...
    // 将所有图片隐藏
    var images = document.getElementsByTagName('img');
        for (var i = 0; i < images.length; i++) {
             images[i].style.display='none';
        }
})();